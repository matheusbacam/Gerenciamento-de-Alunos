package br.com.gerenciamento.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.com.gerenciamento.model.Aluno;

public interface AlunoDao extends JpaRepository<Aluno, Integer> {

	@Query("select i from Aluno i where i.matricula = :matricula")
	public Aluno findByMatricula(int matricula);
}
