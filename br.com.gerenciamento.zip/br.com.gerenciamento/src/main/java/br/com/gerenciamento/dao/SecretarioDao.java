package br.com.gerenciamento.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.com.gerenciamento.model.Secretario;

public interface SecretarioDao extends JpaRepository<Secretario, Long> {
	
	@Query("select i from Secretario i where i.email = :email")
	public Secretario findByEmail(String email);
	
	@Query("select g from Secretario g where g.usuario = :usuario and g.senha = :senha")
	public Secretario buscarLogin(String usuario, String senha);

}
