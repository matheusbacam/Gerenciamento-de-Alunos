package br.com.gerenciamento.controller;

import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.gerenciamento.dao.SecretarioDao;
import br.com.gerenciamento.model.Aluno;
import br.com.gerenciamento.model.Secretario;
import br.com.gerenciamento.service.ServiceExcept;
import br.com.gerenciamento.service.ServicoSecretario;
import br.com.gerenciamento.util.Util;

@Controller
public class SecretarioController {
	
	@Autowired
	private SecretarioDao secretarioRepositorio;
	
	@Autowired
	private ServicoSecretario servicoSecretario;
		
	@GetMapping("/cadastro")
	public ModelAndView cadastrar() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("secretario", new Secretario());
		mv.setViewName("Login/cadastro");
		return mv;
	}
	
	@PostMapping("salvarUsuario")
	public ModelAndView cadastrar(Secretario secretario) throws Exception {
		ModelAndView mv = new ModelAndView();
		servicoSecretario.salvarUsuario(secretario);
		mv.setViewName("redirect:/");
				return mv;
	}
	
	@GetMapping("/index")
    public ModelAndView index() {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("home/index");
        mv.addObject("aluno", new Aluno());
        return mv;
    }
	
	@GetMapping("/")
	public ModelAndView login() {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("Login/login");
        mv.addObject("secretario", new Secretario());
        return mv;
	}
	
	@PostMapping("/login")
	public ModelAndView loginSecretario(@Valid Secretario secretario, BindingResult br, HttpSession session) throws NoSuchAlgorithmException, ServiceExcept {
		ModelAndView mv = new ModelAndView();
		mv.addObject("secretario",new Secretario());
		if(br.hasErrors()) {
			mv.setViewName("Login/login");
		}
		
		Secretario loginSecretario = servicoSecretario.loginSecretario(secretario.getUsuario(), Util.md5(secretario.getSenha()));
		if(loginSecretario == null) {
			mv.addObject("msg","Usuário não encontrado. Tente novamente");
			mv.setViewName("Login/login");
		}else {
			session.setAttribute("secretarioLogado", loginSecretario);
			return index();
		}
		return mv;
	}
	
	@PostMapping("/logout")
	public ModelAndView logout(HttpSession session) {
		session.invalidate();
		return login();
		
	}
	

    }

	

