package br.com.gerenciamento.Exception;

public class CriptoExistException extends Exception {

	public CriptoExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	private static final long serialVersionUID = 1L;

}
