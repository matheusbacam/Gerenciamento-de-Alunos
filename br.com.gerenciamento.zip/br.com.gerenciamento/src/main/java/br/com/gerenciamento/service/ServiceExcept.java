package br.com.gerenciamento.service;

public class ServiceExcept extends Exception {

	public ServiceExcept(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	private static final long serialVersionUID = 1L;

}
