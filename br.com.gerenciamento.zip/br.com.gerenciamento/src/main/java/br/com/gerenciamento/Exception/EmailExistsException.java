package br.com.gerenciamento.Exception;

public class EmailExistsException extends Exception {

	public EmailExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	private static final long serialVersionUID = 1L;
	
	

}
