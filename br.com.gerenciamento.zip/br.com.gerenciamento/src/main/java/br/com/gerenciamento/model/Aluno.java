package br.com.gerenciamento.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Aluno {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "nomeAluno")
	@Size(min = 5, max = 50, message = "O campo deve conter nome e sobrenome.")
	@NotBlank(message = "O campo nome não pode estar em branco.")
	private String nome;

	@Column(name = "endereco")
	@NotBlank(message = "O campo endereço não pode estar em branco.")
	private String endereco;

	@Column(name = "matricula")
	@NotNull(message = "O campo matrícula não pode ficar em branco.")
	private int matricula;

	@Column(name = "telefone")
	@NotNull(message = "O campo telefone não pode ficar em branco.")
	private Long telefone;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public Long getTelefone() {
		return telefone;
	}

	public void setTelefone(Long telefone) {
		this.telefone = telefone;
	}

}
