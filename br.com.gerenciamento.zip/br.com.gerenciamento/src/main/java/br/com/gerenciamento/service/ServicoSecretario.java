package br.com.gerenciamento.service;

import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.gerenciamento.Exception.CriptoExistException;
import br.com.gerenciamento.Exception.EmailExistsException;
import br.com.gerenciamento.dao.SecretarioDao;
import br.com.gerenciamento.model.Secretario;
import br.com.gerenciamento.util.Util;

@Service
public class ServicoSecretario {
	
	@Autowired
	private SecretarioDao repositorioSecretario;
	
	public void salvarUsuario(Secretario secretario) throws Exception{
		
		try {
			if(repositorioSecretario.findByEmail(secretario.getEmail()) != null){
				throw new EmailExistsException("Já existe um email cadastrado " + secretario.getEmail());
				
			}
			
			secretario.setSenha(Util.md5(secretario.getSenha()));
			
		}catch (NoSuchAlgorithmException e) {
			
			throw new CriptoExistException("Erro na criptografia da senha.");
			
		}
		
		repositorioSecretario.save(secretario);
		
	}
	
	public Secretario loginSecretario(String usuario, String senha)  throws ServiceExcept{
		
		Secretario secretarioLogin = repositorioSecretario.buscarLogin(usuario, senha);
		return secretarioLogin;
		
		
	}
	
	

}
